# CampusDesk — Student Management System

A starter student-management web application built with ASP.NET Core MVC, C#, Entity Framework Core, SQLite, and ASP.NET Core Identity.

## Included features
- Admin dashboard: total students, today's present/absent counts, and average recorded grade
- Student records: create, search, edit, and delete
- Attendance: record Present, Absent, or Late per student and date
- Grades: add and delete scores by subject and grading period
- ASP.NET Core Identity sign-in and role-protected management controllers
- Responsive interface

## Requirements
- .NET 8 SDK
- Visual Studio 2022 (ASP.NET and web development workload) or a terminal

## Run locally
1. Unzip this project.
2. Open a terminal in the `StudentManagementSystem` folder.
3. Run `dotnet restore`.
4. Configure an administrator account using environment variables before running the app.

### PowerShell
```powershell
$env:SeedAdmin__Email = "admin@example.com"
$env:SeedAdmin__Password = "Use-A-Unique-Password-123!"
dotnet run
```

### macOS/Linux
```bash
export SeedAdmin__Email="admin@example.com"
export SeedAdmin__Password="Use-A-Unique-Password-123!"
dotnet run
```

Use the HTTPS/HTTP local address printed by `dotnet run`, then sign in with the configured email and password. Do not use the example password above in a real deployment; choose a unique secret.

## Database
The SQLite database is created as `students.db` at first launch. This starter uses `EnsureCreated` for a simple local setup. For ongoing development or production, switch to EF Core migrations (`dotnet ef migrations add InitialCreate` and `dotnet ef database update`) and remove `EnsureCreated`.

## Authentication and authorization notes
- ASP.NET Core Identity stores password hashes rather than plaintext passwords.
- Management controllers require the `Admin` role.
- The first configured seed account is assigned the `Admin` role.
- No default administrator password is embedded in source code.
- The default Identity UI is provided by ASP.NET Core Identity's Razor Pages.
- HTTPS redirection and HTTP-only auth cookies are configured.

## Before production
This is a starter, not a fully audited school information system. Before deployment:
- Use HTTPS only and configure secure cookie settings for the production domain.
- Store secrets in a secret manager or deployment environment; never commit credentials.
- Use EF Core migrations and automated database backups.
- Add audit logs, data-retention rules, role management, and explicit policies for access to student records.
- Add automated tests and review privacy obligations applicable to student data.
- Consider concurrency handling and CSV/PDF exports if needed.

## Project structure
- `Controllers/` — dashboard, student, attendance, and grade endpoints
- `Models/` — EF Core entities and validation
- `Data/` — Identity + application database context
- `Views/` — Razor MVC pages
- `wwwroot/` — CSS and JavaScript
