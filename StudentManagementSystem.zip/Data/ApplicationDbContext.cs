using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using StudentManagementSystem.Models;

namespace StudentManagementSystem.Data;

public class ApplicationDbContext : IdentityDbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<Student> Students => Set<Student>();
    public DbSet<AttendanceRecord> AttendanceRecords => Set<AttendanceRecord>();
    public DbSet<GradeRecord> GradeRecords => Set<GradeRecord>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        builder.Entity<Student>().HasIndex(s => s.StudentNumber).IsUnique();
        builder.Entity<AttendanceRecord>()
            .HasIndex(a => new { a.StudentId, a.Date }).IsUnique();
        builder.Entity<AttendanceRecord>()
            .HasOne(a => a.Student).WithMany(s => s.AttendanceRecords)
            .HasForeignKey(a => a.StudentId).OnDelete(DeleteBehavior.Cascade);
        builder.Entity<GradeRecord>()
            .HasOne(g => g.Student).WithMany(s => s.GradeRecords)
            .HasForeignKey(g => g.StudentId).OnDelete(DeleteBehavior.Cascade);
    }
}
