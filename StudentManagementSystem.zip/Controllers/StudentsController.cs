using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagementSystem.Data;
using StudentManagementSystem.Models;

namespace StudentManagementSystem.Controllers;

[Authorize(Roles = "Admin")]
public class StudentsController : Controller
{
    private readonly ApplicationDbContext _db;
    public StudentsController(ApplicationDbContext db) => _db = db;

    public async Task<IActionResult> Index(string? search)
    {
        var query = _db.Students.AsQueryable();
        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(s => s.FirstName.Contains(search) || s.LastName.Contains(search) || s.StudentNumber.Contains(search));
        ViewData["Search"] = search;
        return View(await query.OrderBy(s => s.LastName).ThenBy(s => s.FirstName).ToListAsync());
    }

    public IActionResult Create() => View(new Student());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Student student)
    {
        if (await _db.Students.AnyAsync(s => s.StudentNumber == student.StudentNumber))
            ModelState.AddModelError(nameof(student.StudentNumber), "That student number is already in use.");
        if (!ModelState.IsValid) return View(student);
        _db.Students.Add(student);
        await _db.SaveChangesAsync();
        TempData["Success"] = "Student created successfully.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Edit(int id)
    {
        var student = await _db.Students.FindAsync(id);
        return student is null ? NotFound() : View(student);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Student student)
    {
        if (id != student.Id) return BadRequest();
        if (await _db.Students.AnyAsync(s => s.StudentNumber == student.StudentNumber && s.Id != id))
            ModelState.AddModelError(nameof(student.StudentNumber), "That student number is already in use.");
        if (!ModelState.IsValid) return View(student);
        _db.Students.Update(student);
        await _db.SaveChangesAsync();
        TempData["Success"] = "Student updated successfully.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Delete(int id)
    {
        var student = await _db.Students.FindAsync(id);
        return student is null ? NotFound() : View(student);
    }

    [HttpPost, ActionName("Delete"), ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var student = await _db.Students.FindAsync(id);
        if (student is not null) { _db.Students.Remove(student); await _db.SaveChangesAsync(); }
        TempData["Success"] = "Student and related records deleted.";
        return RedirectToAction(nameof(Index));
    }
}
