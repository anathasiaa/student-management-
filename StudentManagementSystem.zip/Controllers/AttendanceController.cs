using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StudentManagementSystem.Data;
using StudentManagementSystem.Models;

namespace StudentManagementSystem.Controllers;

[Authorize(Roles = "Admin")]
public class AttendanceController : Controller
{
    private readonly ApplicationDbContext _db;
    public AttendanceController(ApplicationDbContext db) => _db = db;

    public async Task<IActionResult> Index(DateTime? date)
    {
        var day = (date ?? DateTime.Today).Date;
        ViewBag.Date = day.ToString("yyyy-MM-dd");
        return View(await _db.AttendanceRecords.Include(a => a.Student)
            .Where(a => a.Date == day).OrderBy(a => a.Student!.LastName).ToListAsync());
    }

    public async Task<IActionResult> Create()
    {
        await PopulateStudents();
        return View(new AttendanceRecord { Date = DateTime.Today });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(AttendanceRecord record)
    {
        if (await _db.AttendanceRecords.AnyAsync(a => a.StudentId == record.StudentId && a.Date == record.Date.Date))
            ModelState.AddModelError("", "Attendance has already been recorded for this student and date.");
        if (!ModelState.IsValid) { await PopulateStudents(); return View(record); }
        record.Date = record.Date.Date;
        _db.AttendanceRecords.Add(record);
        await _db.SaveChangesAsync();
        TempData["Success"] = "Attendance recorded.";
        return RedirectToAction(nameof(Index), new { date = record.Date.ToString("yyyy-MM-dd") });
    }

    private async Task PopulateStudents() =>
        ViewBag.Students = new SelectList(await _db.Students.OrderBy(s => s.LastName).ToListAsync(), "Id", "FullName");
}
