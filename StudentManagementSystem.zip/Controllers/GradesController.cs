using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StudentManagementSystem.Data;
using StudentManagementSystem.Models;

namespace StudentManagementSystem.Controllers;

[Authorize(Roles = "Admin")]
public class GradesController : Controller
{
    private readonly ApplicationDbContext _db;
    public GradesController(ApplicationDbContext db) => _db = db;

    public async Task<IActionResult> Index(string? search)
    {
        var query = _db.GradeRecords.Include(g => g.Student).AsQueryable();
        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(g => g.Student!.FirstName.Contains(search) || g.Student.LastName.Contains(search) || g.Subject.Contains(search));
        ViewData["Search"] = search;
        return View(await query.OrderBy(g => g.Student!.LastName).ThenBy(g => g.Subject).ToListAsync());
    }

    public async Task<IActionResult> Create()
    {
        await PopulateStudents();
        return View(new GradeRecord());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(GradeRecord grade)
    {
        if (!ModelState.IsValid) { await PopulateStudents(); return View(grade); }
        _db.GradeRecords.Add(grade);
        await _db.SaveChangesAsync();
        TempData["Success"] = "Grade saved.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Delete(int id)
    {
        var grade = await _db.GradeRecords.Include(g => g.Student).FirstOrDefaultAsync(g => g.Id == id);
        return grade is null ? NotFound() : View(grade);
    }

    [HttpPost, ActionName("Delete"), ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var grade = await _db.GradeRecords.FindAsync(id);
        if (grade is not null) { _db.GradeRecords.Remove(grade); await _db.SaveChangesAsync(); }
        TempData["Success"] = "Grade deleted.";
        return RedirectToAction(nameof(Index));
    }

    private async Task PopulateStudents() =>
        ViewBag.Students = new SelectList(await _db.Students.OrderBy(s => s.LastName).ToListAsync(), "Id", "FullName");
}
