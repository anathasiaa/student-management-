using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagementSystem.Data;
using StudentManagementSystem.Models;
using StudentManagementSystem.ViewModels;

namespace StudentManagementSystem.Controllers;

[Authorize]
public class HomeController : Controller
{
    private readonly ApplicationDbContext _db;
    public HomeController(ApplicationDbContext db) => _db = db;

    public async Task<IActionResult> Index()
    {
        var today = DateTime.Today;
        var vm = new DashboardViewModel
        {
            TotalStudents = await _db.Students.CountAsync(),
            PresentToday = await _db.AttendanceRecords.CountAsync(a => a.Date == today && a.Status == AttendanceStatus.Present),
            AbsentToday = await _db.AttendanceRecords.CountAsync(a => a.Date == today && a.Status == AttendanceStatus.Absent),
            LateToday = await _db.AttendanceRecords.CountAsync(a => a.Date == today && a.Status == AttendanceStatus.Late),
            AverageGrade = await _db.GradeRecords.Select(g => (decimal?)g.Score).AverageAsync() ?? 0,
            RecentStudents = await _db.Students.OrderByDescending(s => s.Id).Take(5).ToListAsync()
        };
        return View(vm);
    }
}
