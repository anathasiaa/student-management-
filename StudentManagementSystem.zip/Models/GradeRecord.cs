using System.ComponentModel.DataAnnotations;

namespace StudentManagementSystem.Models;

public class GradeRecord
{
    public int Id { get; set; }
    [Required] public int StudentId { get; set; }
    public Student? Student { get; set; }

    [Required, StringLength(100)]
    public string Subject { get; set; } = "";

    [Required, StringLength(40)]
    [Display(Name = "Grading period")]
    public string GradingPeriod { get; set; } = "Quarter 1";

    [Range(0, 100)]
    public decimal Score { get; set; }

    [StringLength(250)]
    public string? Remarks { get; set; }
}
