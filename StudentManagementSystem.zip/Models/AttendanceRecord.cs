using System.ComponentModel.DataAnnotations;

namespace StudentManagementSystem.Models;

public class AttendanceRecord
{
    public int Id { get; set; }
    [Required] public int StudentId { get; set; }
    public Student? Student { get; set; }

    [DataType(DataType.Date)]
    public DateTime Date { get; set; } = DateTime.Today;

    [Required]
    public AttendanceStatus Status { get; set; } = AttendanceStatus.Present;

    [StringLength(250)]
    public string? Notes { get; set; }
}

public enum AttendanceStatus { Present, Absent, Late }
