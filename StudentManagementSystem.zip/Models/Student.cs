using System.ComponentModel.DataAnnotations;

namespace StudentManagementSystem.Models;

public class Student
{
    public int Id { get; set; }

    [Required, StringLength(20)]
    [Display(Name = "Student number")]
    public string StudentNumber { get; set; } = "";

    [Required, StringLength(80)]
    [Display(Name = "First name")]
    public string FirstName { get; set; } = "";

    [Required, StringLength(80)]
    [Display(Name = "Last name")]
    public string LastName { get; set; } = "";

    [EmailAddress, StringLength(160)]
    public string? Email { get; set; }

    [StringLength(80)]
    public string? GradeLevel { get; set; }

    [DataType(DataType.Date)]
    public DateTime EnrollmentDate { get; set; } = DateTime.Today;

    public ICollection<AttendanceRecord> AttendanceRecords { get; set; } = new List<AttendanceRecord>();
    public ICollection<GradeRecord> GradeRecords { get; set; } = new List<GradeRecord>();

    public string FullName => $"{FirstName} {LastName}";
}
