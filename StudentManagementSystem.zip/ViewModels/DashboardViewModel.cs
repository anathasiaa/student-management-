using StudentManagementSystem.Models;

namespace StudentManagementSystem.ViewModels;

public class DashboardViewModel
{
    public int TotalStudents { get; set; }
    public int PresentToday { get; set; }
    public int AbsentToday { get; set; }
    public int LateToday { get; set; }
    public decimal AverageGrade { get; set; }
    public List<Student> RecentStudents { get; set; } = new();
}
