document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".alert-success").forEach((el) => {
    window.setTimeout(() => {
      el.style.transition = "opacity .4s ease";
      el.style.opacity = "0";
      window.setTimeout(() => el.remove(), 450);
    }, 4500);
  });
});